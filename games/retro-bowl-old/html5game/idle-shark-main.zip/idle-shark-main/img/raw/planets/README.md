Planet textures
